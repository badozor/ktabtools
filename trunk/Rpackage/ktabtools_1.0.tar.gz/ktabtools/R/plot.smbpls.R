plot.smbpls <-
function (...) 
{
    .NotYetImplemented()
}
