mbpls <-
function (X, ...) 
{
    UseMethod("mbpls")
}
