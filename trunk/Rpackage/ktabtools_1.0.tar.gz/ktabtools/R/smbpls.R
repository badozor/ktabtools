smbpls <-
function (X, ...) 
{
    UseMethod("smbpls")
}
