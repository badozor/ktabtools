valid.smbpls <-
function (...) 
{
    .NotYetImplemented()
}
