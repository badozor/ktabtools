summary.smbpls <-
function (...) 
{
    .NotYetImplemented()
}
