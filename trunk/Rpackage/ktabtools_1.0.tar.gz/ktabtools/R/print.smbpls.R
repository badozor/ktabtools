print.smbpls <-
function (...) 
{
    .NotYetImplemented()
}
