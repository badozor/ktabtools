plot.mbpls <-
function (...) 
{
    .NotYetImplemented()
}
