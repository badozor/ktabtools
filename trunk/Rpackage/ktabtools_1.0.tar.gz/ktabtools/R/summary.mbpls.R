summary.mbpls <-
function (...) 
{
    .NotYetImplemented()
}
