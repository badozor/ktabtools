kplot.mbpls <-
function (...) 
{
    .NotYetImplemented()
}
