kplot.smbpls <-
function (...) 
{
    .NotYetImplemented()
}
